#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_ROWS 100
#define MAX_COLUMNS 100

// Structure to represent a maze
typedef struct {
    int rows;
    int columns;
    char cells[MAX_ROWS][MAX_COLUMNS];
    int currentCol;
    int currentRow;
    int startCol;
    int startRow;
    int endCol;
    int endRow;
} Maze;

// Function prototypes
Maze loadMazeFromFile(FILE *file);
void displayMaze(Maze maze);
void moveUp(Maze maze);
void moveDown(Maze maze);
void moveRight(Maze maze);
void moveLeft(Maze maze);
void printMap(Maze maze);
void endGame();

int main(int argc, char *argv[]) {
    // Check for correct number of command-line arguments
    if (argc != 2) {
        printf("Usage: studentData <filename>");
        return EXIT_FAILURE;
    }

    // Open the maze file
    FILE *file = fopen(argv[1], "r");
    if (file == NULL) {
        printf("Error: Bad filename");
        return EXIT_FAILURE;
    }

    Maze maze = loadMazeFromFile(file);


    // Close the file
    fclose(file);

    displayMaze(maze);

    // Navigation
    char key;
    do {
        scanf("\r%c", &key);

        switch (key) {
            case 'w':
            case 'W':
                moveUp(maze);
                break;
            case 's':
            case 'S':
                moveDown(maze);
                break;
            case 'd':
            case 'D':
                moveRight(maze);
                break;
            case 'a':
            case 'A':
                moveLeft(maze);
                break;
            case 'm':
            case 'M':
                printMap(maze);
                break;
            default:
                printf("Error: invalid key\n");
        }

    } while (1);

    return EXIT_SUCCESS;
}



Maze loadMazeFromFile(FILE *file) {
    Maze maze;
    int row = 0, column = 0;
    char ch;

    // in this function, the game will scan the maze file and store each of the wall
    // and identify the starting row and column
    // and the ending row and column
    while ((ch = fgetc(file)) != EOF) {
        
    }
    maze.columns = column;   
    return maze;
}

void moveUp(Maze maze){
    // in this function, the game will check if the 'up' movement is valid or not

    // if movement is valid
        // the current row and column will be updated
    // if movement invalid
        // it will check if there is a wall up ahead
            printf("Dialogue : can't move up. There is a wall\n");
        // else
            printf("Dialogue : can't move up. That's the edge\n");
    // if its the end of the maze

}

void moveDown(Maze maze){
    // in this function, the game will check if the 'down' movement is valid or not

    // if movement is valid
        // the current row and column will be updated
    // if movement invalid
        // it will check if there is a wall up ahead
            printf("Dialogue : can't move down. There is a wall\n");
        // else
            printf("Dialogue : can't move down. That's the edge\n");
}

void moveRight(Maze maze){
    // in this function, the game will check if the 'right' movement is valid or not

    // if movement is valid
        // the current row and column will be updated
    // if movement invalid
        // it will check if there is a wall up ahead
            printf("Dialogue : can't move right. There is a wall\n");
        // else
            printf("Dialogue : can't move right. That's the edge\n");
}

void moveRight(Maze maze){
    // in this function, the game will check if the 'left' movement is valid or not

    // if movement is valid
        // the current row and column will be updated
    // if movement invalid
        // it will check if there is a wall up ahead
            printf("Dialogue : can't move left. There is a wall\n");
        // else
            printf("Dialogue : can't move left. That's the edge\n");
}

void printMap(Maze maze){
    // in this function, the program will printf the whole map
    // and replace the current position with X
}

void endGame(){
    printf("You won!\n");
    return EXIT_SUCCESS;
}